
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// src/endpoints/trpc.ts
import { createNetlifyTRPCHandler } from "@netlify/sdk/ui/functions/trpc";

// src/server/router.ts
import { TRPCError } from "@trpc/server";

// src/server/trpc.ts
import { initTRPC } from "@trpc/server";
var trpc = initTRPC.context().create();
var router = trpc.router;
var procedure = trpc.procedure;

// src/lib/settings.ts
import { z } from "zod";
var MODULES = ["engage", "auto", "vitals", "clicks", "ask"];
var SPA_MODES = ["auto", "history", "hash", "off"];
var SITE_ID_PATTERN = /^pa_[A-Za-z0-9]{4,40}$/;
var GLOB_PATTERN = /^[A-Za-z0-9/_*?.\-~%:@!+]{1,200}$/;
var HOSTNAME_PATTERN = /^(localhost|(?=.{1,253}$)([A-Za-z0-9-]{1,63}\.)+[A-Za-z]{2,63})$/;
var siteId = z.string().trim().regex(SITE_ID_PATTERN, "The site ID looks like pa_7Q2K9XH3AB. Copy it from Site settings, Tracking in Privatus Analytics.");
var glob = z.string().trim().regex(GLOB_PATTERN, "Use letters, numbers and / * ? . - _ ~ % : @ ! + only.");
var hostname = z.string().trim().toLowerCase().regex(HOSTNAME_PATTERN, "Enter a hostname such as www.example.com.");
var optionalFields = {
  modules: z.array(z.enum(MODULES)).max(MODULES.length).optional(),
  spa: z.enum(SPA_MODES).optional(),
  /** Paths the tracker never counts (data-exclude), for example /admin/*. */
  exclude: z.array(glob).max(50).optional(),
  /** Hostnames the tracker counts on (data-domains). Empty means every hostname. */
  domains: z.array(hostname).max(50).optional(),
  /** HTML files in the publish directory that are left without the script. */
  skipFiles: z.array(glob).max(50).optional(),
  trackPreviews: z.boolean().optional(),
  trackBranchDeploys: z.boolean().optional()
};
var SiteConfigSchema = z.object({
  enabled: z.boolean().default(true),
  siteId,
  ...optionalFields
});
var TeamConfigSchema = z.object({ ...optionalFields });
var BuildConfigSchema = z.object({
  enabled: z.boolean().optional(),
  siteId: siteId.optional(),
  ...optionalFields
});

// src/lib/html.ts
var withoutComments = (html) => html.replace(/<!--[\s\S]*?(?:-->|$)/g, "");
var SCRIPT_TAG = /<script\b[^>]*>/gi;
var TRACKER_SRC = /\bsrc\s*=\s*(?:"[^"]*\/js\/pa\.js(?:[?#][^"]*)?"|'[^']*\/js\/pa\.js(?:[?#][^']*)?'|[^\s"'>]*\/js\/pa\.js(?:[?#][^\s>]*)?(?=[\s>]))/i;
var DATA_SITE = /\bdata-site\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))/i;
var detectTracker = (html) => {
  const text = withoutComments(html);
  let match;
  const tags = new RegExp(SCRIPT_TAG.source, "gi");
  while (match = tags.exec(text)) {
    const tag = match[0];
    if (TRACKER_SRC.test(tag)) {
      const site = DATA_SITE.exec(tag);
      const siteId2 = site ? site[1] ?? site[2] ?? site[3] : void 0;
      return siteId2 ? { present: true, siteId: siteId2 } : { present: true };
    }
  }
  if (/data-privatus-loader/.test(text) && /\/js\/pa\.js/.test(text)) {
    const inline = /"data-site"\s*:\s*"([^"]+)"/.exec(text);
    return inline && inline[1] ? { present: true, siteId: inline[1] } : { present: true };
  }
  return { present: false };
};

// src/lib/verify.ts
var MAX_BYTES = 2 * 1024 * 1024;
var verifyPublishedPage = async (url, expectedSiteId, fetchImpl = fetch) => {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return { status: "unreachable", message: "The project has no published address yet." };
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    return { status: "unreachable", message: "The project address is not a web address." };
  }
  let response;
  try {
    response = await fetchImpl(parsed, { redirect: "follow", signal: AbortSignal.timeout(1e4), headers: { accept: "text/html" } });
  } catch (error) {
    return { status: "unreachable", message: error instanceof Error ? error.message : "The page could not be loaded." };
  }
  if (!response.ok) return { status: "unreachable", message: `The page responded with ${response.status}.` };
  const html = (await response.text()).slice(0, MAX_BYTES);
  const found = detectTracker(html);
  if (!found.present) return { status: "not-found" };
  return { status: "found", siteId: found.siteId ?? null, matches: found.siteId === expectedSiteId };
};

// src/server/router.ts
var need = (value, name) => {
  if (!value) throw new TRPCError({ code: "BAD_REQUEST", message: `${name} is required` });
  return value;
};
var publishedUrl = (site) => site.custom_domain ? `https://${site.custom_domain}` : site.ssl_url ?? site.url;
var appRouter = router({
  teamSettings: {
    query: procedure.query(async ({ ctx: { teamId, client } }) => {
      const config2 = await client.getTeamConfiguration(need(teamId, "teamId"));
      if (!config2) return null;
      const parsed = TeamConfigSchema.safeParse(config2.config);
      return parsed.success ? parsed.data : null;
    }),
    mutate: procedure.input(TeamConfigSchema).mutation(async ({ ctx: { teamId, client }, input }) => {
      try {
        await client.upsertTeamConfiguration(need(teamId, "teamId"), input);
      } catch (cause) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The team defaults could not be saved.", cause });
      }
    })
  },
  siteSettings: {
    query: procedure.query(async ({ ctx: { teamId, siteId: siteId2, client } }) => {
      const config2 = await client.getSiteConfiguration(need(teamId, "teamId"), need(siteId2, "siteId"));
      if (!config2) return null;
      const parsed = SiteConfigSchema.safeParse(config2.config);
      return parsed.success ? parsed.data : null;
    }),
    mutate: procedure.input(SiteConfigSchema).mutation(async ({ ctx: { teamId, siteId: siteId2, client }, input }) => {
      try {
        await client.upsertSiteConfiguration(need(teamId, "teamId"), need(siteId2, "siteId"), input);
      } catch (cause) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The project settings could not be saved.", cause });
      }
    })
  },
  /** Looks for the script on the published home page. Reads one public page and nothing else. */
  verify: {
    check: procedure.mutation(async ({ ctx: { teamId, siteId: siteId2, client } }) => {
      const config2 = await client.getSiteConfiguration(need(teamId, "teamId"), need(siteId2, "siteId"));
      const parsed = SiteConfigSchema.safeParse(config2?.config);
      if (!parsed.success) return { status: "unreachable", message: "Save a site ID first." };
      const site = await client.getSite(need(siteId2, "siteId"));
      const url = publishedUrl(site);
      if (!url) return { status: "unreachable", message: "This project has not been published yet." };
      return { url, ...await verifyPublishedPage(url, parsed.data.siteId) };
    })
  }
});

// src/endpoints/trpc.ts
var config = {
  path: ["/api/trpc{/*}?"]
};
var handler = createNetlifyTRPCHandler({
  endpoint: "/api/trpc",
  router: appRouter
});
var trpc_default = handler;
export {
  config,
  trpc_default as default
};
